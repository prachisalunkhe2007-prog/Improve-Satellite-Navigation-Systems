function [BER, numErrors] = calculateBER(originalBits, recoveredBits)

originalBits = originalBits(:);

recoveredBits = recoveredBits(:);

if length(originalBits) ~= length(recoveredBits)
    error('Original and recovered bit vectors must have the same length.');
end

numErrors = sum(originalBits ~= recoveredBits);

BER = numErrors / length(originalBits);

end