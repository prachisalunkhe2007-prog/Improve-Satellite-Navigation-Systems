function navBits = createNavigationMessage()

%% BeiDou B-CNAV2 fields

PRN = randi([0 1],6,1);

MessageType = randi([0 1],6,1);

SOW = randi([0 1],18,1);

Data = randi([0 1],234,1);

%% 264 bits participating in CRC

messageWithoutCRC = [
    PRN;
    MessageType;
    SOW;
    Data
    ];

%% Calculate actual CRC-24Q

CRC = calculateCRC24Q(messageWithoutCRC);

%% Complete 288-bit frame

navBits = [
    messageWithoutCRC;
    CRC
    ];

if length(navBits) ~= 288

    error('Navigation message length is incorrect.');

end

end