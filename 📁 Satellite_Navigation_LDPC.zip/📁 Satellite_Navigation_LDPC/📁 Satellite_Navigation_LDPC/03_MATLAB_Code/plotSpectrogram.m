function plotSpectrogram(txPayload, rxPayload, resultsDir)

txPayload = double(txPayload(:));
rxPayload = double(rxPayload(:));

% Samples per BPSK symbol for visualization
samplesPerSymbol = 16;

% Expand symbols into a sampled waveform
txWaveform = repelem(txPayload, samplesPerSymbol);
rxWaveform = repelem(rxPayload, samplesPerSymbol);

% Normalized sampling frequency
Fs = 16;

figure;

subplot(2,1,1);

spectrogram(txWaveform, ...
    hamming(128), 112, 256, Fs, 'yaxis');

title('Spectrogram of Transmitted BPSK Signal');
colorbar;

subplot(2,1,2);

spectrogram(rxWaveform, ...
    hamming(128), 112, 256, Fs, 'yaxis');

title('Spectrogram of Received Signal after AWGN');
colorbar;

sgtitle('Spectrogram Comparison');

saveas(gcf, fullfile(resultsDir, ...
    'Spectrogram_Comparison.png'));

end