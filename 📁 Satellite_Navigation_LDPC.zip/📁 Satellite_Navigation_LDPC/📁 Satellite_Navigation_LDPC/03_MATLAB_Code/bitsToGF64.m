function gfSymbols = bitsToGF64(bits)

% Number of bits per GF(64) symbol
m = 6;

% Primitive polynomial:
% x^6 + x + 1
primitivePolynomial = 67;

% Make sure input is a column vector
bits = bits(:);

% Check input length
if mod(length(bits),m) ~= 0
    error('Number of bits must be divisible by 6.');
end

% Divide bits into groups of 6
bitGroups = reshape(bits,m,[])';

% Binary to decimal conversion
weights = 2.^(m-1:-1:0);
decimalSymbols = bitGroups * weights';

% Convert decimal values into GF(64)
gfSymbols = gf(decimalSymbols,m,primitivePolynomial);

end