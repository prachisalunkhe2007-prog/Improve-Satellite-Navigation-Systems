function codeword = ldpc64Encoder(infoSymbols,H)

k = 48;

% Check dimensions
if size(H,1) ~= 48 || size(H,2) ~= 96
    error('H matrix must be 48 x 96.');
end

% Split H = [A B]
A = H(:,1:k);
B = H(:,k+1:end);

% Information symbols
u = infoSymbols(:);

% Calculate parity symbols
parity = B \ (A*u);

% Complete codeword
codeword = [
    u;
    parity
    ];

end