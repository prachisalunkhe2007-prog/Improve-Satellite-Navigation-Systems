function [decodedInfo, success, iterations] = ...
    ldpc64Decoder(rxData, noiseVariance, H, maxIter, nm)

mGF = 6;
q = 64;
primitivePolynomial = 67;

numChecks = size(H,1);
numVars = size(H,2);

offset = 5;

rxData = rxData(:);

if length(rxData) ~= numVars*mGF
    error('Receiver input must contain 576 BPSK samples.');
end




%% Channel Reliability

channelMetric = zeros(numVars,q);

for symbol = 0:q-1

    symbolBits = bitget(symbol,mGF:-1:1);

    expectedSignal = 1 - 2*symbolBits;

    for j = 1:numVars

        difference = rxGroups(j,:) - expectedSignal;

        channelMetric(j,symbol+1) = ...
            sum(difference.^2) / (2*noiseVariance);

    end

end


%% Normalize

for j = 1:numVars
    channelMetric(j,:) = ...
        channelMetric(j,:) - min(channelMetric(j,:));
end


%% GF Multiplication Table

gfValues = gf(0:q-1,mGF,primitivePolynomial);

mulTable = zeros(q,q);

for h = 0:q-1

    temp = gf(h,mGF,primitivePolynomial) .* gfValues;

    mulTable(h+1,:) = temp.x;

end


%% Initialize messages

V2C = inf(numChecks,numVars,q);

C2V = inf(numChecks,numVars,q);


for i = 1:numChecks

    neighbours = find(H.x(i,:) ~= 0);

    for j = neighbours

        metric = channelMetric(j,:);

        metric = truncateMetric(metric,nm,offset);

        V2C(i,j,:) = reshape(metric,1,1,q);

    end

end


%% Initial Hard Decision

hardSymbols = zeros(numVars,1);

for j = 1:numVars

    [~,indexMin] = min(channelMetric(j,:));

    hardSymbols(j) = indexMin - 1;

end


hardGF = gf(hardSymbols,mGF,primitivePolynomial);

syndrome = H * hardGF;


if all(syndrome.x == 0)

    decodedInfo = hardGF(1:48);

    success = true;

    iterations = 0;

    return;

end


%% Iterative EMS Decoding

success = false;

for iteration = 1:maxIter


    %% Check Node Update

    for i = 1:numChecks

        neighbours = find(H.x(i,:) ~= 0);

        for outIndex = 1:length(neighbours)

            jOut = neighbours(outIndex);

            others = neighbours;

            others(outIndex) = [];


            combined = inf(1,q);

            combined(1) = 0;


            for jOther = others

                hValue = H.x(i,jOther);

                inputMetric = ...
                    squeeze(V2C(i,jOther,:))';

                transformed = inf(1,q);

                map = mulTable(hValue+1,:);

                transformed(map+1) = inputMetric;

                combined = ...
                    minXorConvolution(combined,transformed);

            end


            hOut = H.x(i,jOut);

            outputMap = mulTable(hOut+1,:);

            message = combined(outputMap+1);

            message = message - min(message);

            message = truncateMetric(message,nm,offset);

            C2V(i,jOut,:) = ...
                reshape(message,1,1,q);

        end

    end


    %% Variable Node Update

    for j = 1:numVars

        checks = find(H.x(:,j) ~= 0)';

        posterior = channelMetric(j,:);


        for i = checks

            posterior = posterior + ...
                squeeze(C2V(i,j,:))';

        end


        [~,bestIndex] = min(posterior);

        hardSymbols(j) = bestIndex - 1;


        for i = checks

            extrinsic = channelMetric(j,:);


            for otherCheck = checks

                if otherCheck ~= i

                    extrinsic = extrinsic + ...
                        squeeze(C2V(otherCheck,j,:))';

                end

            end


            extrinsic = ...
                truncateMetric(extrinsic,nm,offset);

            V2C(i,j,:) = ...
                reshape(extrinsic,1,1,q);

        end

    end


    %% Syndrome Check

    hardGF = gf( ...
        hardSymbols, ...
        mGF, ...
        primitivePolynomial);

    syndrome = H * hardGF;


    if all(syndrome.x == 0)

        success = true;

        iterations = iteration;

        decodedInfo = hardGF(1:48);

        return;

    end

end


iterations = maxIter;

decodedInfo = hardGF(1:48);

end



function output = truncateMetric(metric,nm,offset)

metric = metric - min(metric);

[sortedMetric,indices] = sort(metric);

output = metric;

keep = indices(1:nm);

discardValue = sortedMetric(nm) + offset;

output(:) = discardValue;

output(keep) = metric(keep);

output = output - min(output);

end



function output = minXorConvolution(A,B)

q = length(A);

output = inf(1,q);

values = 0:q-1;


for s = 0:q-1

    other = bitxor(values,s);

    candidate = A + B(other+1);

    output(s+1) = min(candidate);

end


output = output - min(output);

end