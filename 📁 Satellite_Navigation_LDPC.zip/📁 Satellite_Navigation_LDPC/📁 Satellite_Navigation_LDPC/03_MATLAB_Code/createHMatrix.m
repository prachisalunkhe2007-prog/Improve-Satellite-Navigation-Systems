clc;
clear;

fprintf('Creating official BeiDou H(48,96) matrix...\n');

%% GF(64) parameters
m = 6;

% p(x) = x^6 + x + 1
primitivePolynomial = 67;


%% Non-zero POSITION data from BeiDou B2a ICD

idxRaw = [
19 46 49 76   5 29 53 71   17 30 64 72   22 36 59 82
22 41 68 94   20 44 54 75   9 41 61 86    6 47 60 89
8 40 60 87    15 26 66 81   19 24 67 95   2 26 50 72
5 38 70 89    16 34 64 92   21 45 55 74   0 24 48 78
23 37 58 83   15 43 56 91   18 47 48 77   14 42 57 90
6 30 54 76    14 27 67 80   17 35 65 93   7 46 61 88
1 25 49 79    12 45 69 79   18 25 66 94   23 40 69 95
8 36 51 84    3 38 56 86    0 29 62 85    2 39 57 87
11 33 59 81   20 43 74 93   13 32 63 91   11 35 52 83
16 31 65 73   4 28 52 70    1 28 63 84    12 33 62 90
21 42 75 92   7 31 55 77    9 37 50 85    10 34 53 82
4 39 71 88    13 44 68 78   3 27 51 73    10 32 58 80
];


%% Non-zero ELEMENT values from BeiDou B2a ICD

elementRaw = [
1 45 15 6     1 44 53 24    45 15 6 1     30 24 1 44
18 15 32 61   3 55 9 34     35 31 50 44   45 15 6 1
24 1 44 53    30 24 1 44    32 42 47 37   6 1 45 15
44 53 24 1    39 36 34 33   44 53 24 1    44 53 24 1
45 15 6 1     6 1 45 15     24 1 44 53    9 41 57 58
32 61 18 40   1 45 15 6     22 14 2 50    24 1 44 30
30 24 1 44    15 46 45 44   45 15 6 1     1 44 30 24
24 1 44 53    15 6 1 45     53 24 1 44    7 38 23 54
1 45 15 6     44 53 24 1    57 25 9 41    35 13 51 60
33 45 36 34   6 1 45 15     6 1 45 15     6 1 45 15
44 35 31 50   26 27 37 5    24 1 44 30    33 42 14 5
24 1 44 30    24 1 44 30    1 44 53 24    1 44 30 24
];


%% Rearrange ICD printed tables into 48 x 4 format

index = zeros(48,4);
element = zeros(48,4);

rowStart = 1;

for block = 1:4

    cols = (block-1)*4 + (1:4);

    index(rowStart:rowStart+11,:) = idxRaw(:,cols);

    element(rowStart:rowStart+11,:) = elementRaw(:,cols);

    rowStart = rowStart + 12;

end


%% Create empty 48 x 96 GF(64) matrix

H = gf(zeros(48,96),m,primitivePolynomial);


%% Insert 4 non-zero elements in each row

for i = 1:48

    for j = 1:4

        % ICD uses column numbering 0...95.
        % MATLAB uses 1...96, therefore +1.
        columnNumber = index(i,j) + 1;

        H(i,columnNumber) = gf(element(i,j),m,primitivePolynomial);

    end

end


%% Verify size

fprintf('H matrix rows    = %d\n',size(H,1));
fprintf('H matrix columns = %d\n',size(H,2));

if size(H,1) == 48 && size(H,2) == 96
    fprintf('Status: PASS - H matrix size is 48 x 96.\n');
else
    fprintf('Status: FAIL - Incorrect H matrix size.\n');
end


%% Verify number of non-zero elements

numberNonZero = nnz(H.x);

fprintf('Non-zero elements = %d\n',numberNonZero);

if numberNonZero == 192
    fprintf('Status: PASS - Correct sparse structure.\n');
else
    fprintf('Status: FAIL - Incorrect sparse structure.\n');
end


%% Save into 04_Data

codeDir = fileparts(mfilename('fullpath'));

projectRoot = fileparts(codeDir);

dataFolder = fullfile(projectRoot,'04_Data');

save(fullfile(dataFolder,'H_matrix.mat'),'H');

fprintf('\nH_matrix.mat saved successfully.\n');
fprintf('Location: %s\n',dataFolder);