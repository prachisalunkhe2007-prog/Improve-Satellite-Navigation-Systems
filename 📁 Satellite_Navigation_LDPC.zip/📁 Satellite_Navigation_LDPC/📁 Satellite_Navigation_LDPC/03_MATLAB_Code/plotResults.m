function plotResults(snrValues, berValues, navBits, txPayload, rxPayload, decodedBits,resultsDir)

if ~exist(resultsDir,'dir')
    mkdir(resultsDir);
end


%% Original Navigation Message

figure('Visible','off');

stem(navBits,'filled');

xlabel('Bit Index');
ylabel('Bit Value');

title('Original 288-bit Navigation Message');

grid on;

exportgraphics(gcf, ...
    fullfile(resultsDir,'Original_Message.png'));

close;


%% BPSK Signal

figure('Visible','off');

plot(txPayload(1:min(100,end)));

xlabel('Symbol Index');
ylabel('Amplitude');

title('BPSK Modulated Signal');

grid on;

exportgraphics(gcf, ...
    fullfile(resultsDir,'BPSK_Signal.png'));

close;


%% Received Signal

figure('Visible','off');

plot(rxPayload(1:min(100,end)));

xlabel('Symbol Index');
ylabel('Amplitude');

title('Received Signal after AWGN');

grid on;

exportgraphics(gcf, ...
    fullfile(resultsDir,'Received_Signal.png'));

close;


%% BER vs SNR

figure('Visible','off');

semilogy(snrValues,berValues,'-o','LineWidth',1.5);

xlabel('SNR (dB)');
ylabel('Bit Error Rate');

title('BER Performance of 64-ary LDPC Navigation System');

grid on;

exportgraphics(gcf, ...
    fullfile(resultsDir,'BER_vs_SNR.png'));

close;


%% Save BER Table

BER_Table = table( ...
    snrValues(:), ...
    berValues(:), ...
    'VariableNames', {'SNR_dB','BER'});

writetable( ...
    BER_Table, ...
    fullfile(resultsDir,'BER_Table.xlsx'));

end