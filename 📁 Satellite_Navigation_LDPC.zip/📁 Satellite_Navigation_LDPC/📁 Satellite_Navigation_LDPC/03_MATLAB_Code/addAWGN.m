function [rxSignal, noiseVariance] = addAWGN(txSignal, SNRdB)

txSignal = txSignal(:);

signalPower = mean(abs(txSignal).^2);

snrLinear = 10^(SNRdB/10);

noiseVariance = signalPower / snrLinear;

noise = sqrt(noiseVariance) .* randn(size(txSignal));

rxSignal = txSignal + noise;

end