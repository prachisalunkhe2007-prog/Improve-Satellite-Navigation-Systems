function plotInputOutput(navBits, decodedBits, resultsDir)

navBits = navBits(:);
decodedBits = decodedBits(:);

if length(navBits) ~= length(decodedBits)
    error('Input and output lengths must match.');
end

figure;

subplot(2,1,1);
stairs(navBits, 'b', 'LineWidth', 1.2);
title('Input: Original Navigation Message');
xlabel('Bit Index');
ylabel('Bit Value');
ylim([-0.2 1.2]);
grid on;

subplot(2,1,2);
stairs(decodedBits, 'r', 'LineWidth', 1.2);
title('Output: LDPC Decoded Navigation Message');
xlabel('Bit Index');
ylabel('Bit Value');
ylim([-0.2 1.2]);
grid on;

sgtitle('Input and Output Comparison');

saveas(gcf, fullfile(resultsDir, ...
    'Input_Output_Comparison.png'));

numErrors = sum(navBits ~= decodedBits);

fprintf('\nInput bits: %d\n', length(navBits));
fprintf('Output bits: %d\n', length(decodedBits));
fprintf('Bit errors: %d\n', numErrors);

end