function crcBits = calculateCRC24Q(dataBits)

dataBits = dataBits(:);

% CRC-24Q generator polynomial
% Non-zero coefficients:
% 24,23,18,17,14,11,10,7,6,5,4,3,1,0

degrees = [24 23 18 17 14 11 10 7 6 5 4 3 1 0];

generator = zeros(25,1);

for k = 1:length(degrees)
    generator(25-degrees(k)) = 1;
end

% Append 24 zeros
work = [dataBits; zeros(24,1)];

% Polynomial division over GF(2)
for i = 1:length(dataBits)

    if work(i) == 1

        work(i:i+24) = xor( ...
            work(i:i+24), ...
            generator);

    end

end

% Last 24 bits are CRC
crcBits = double(work(end-23:end));

end