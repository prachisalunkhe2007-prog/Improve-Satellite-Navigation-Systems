
clc;
clear;
close all;

fprintf('============================================\n');
fprintf(' SATELLITE NAVIGATION LDPC PROJECT\n');
fprintf('============================================\n\n');

fprintf('MATLAB project started successfully.\n\n');

%% =========================================================
% STEP 1: Create Navigation Message
% ==========================================================

navBits = createNavigationMessage();

fprintf('STEP 1: Navigation message generated successfully.\n');
fprintf('Navigation message length = %d bits\n', length(navBits));

if length(navBits) == 288
    fprintf('Status: PASS - Correct 288-bit frame generated.\n');
else
    fprintf('Status: FAIL - Incorrect frame length.\n');
end

%% =========================================================
% STEP 2: Convert Navigation Bits to GF(64)
% ==========================================================

infoSymbols = bitsToGF64(navBits);

fprintf('\nSTEP 2: GF(64) conversion completed.\n');
fprintf('Number of input bits = %d\n', length(navBits));
fprintf('Number of GF(64) symbols = %d\n', length(infoSymbols.x));

if length(infoSymbols.x) == 48
    fprintf('Status: PASS - Correct 48 GF(64) symbols generated.\n');
else
    fprintf('Status: FAIL - Incorrect number of GF(64) symbols.\n');
end

%% =========================================================
% STEP 3: Convert GF(64) Symbols Back to Bits
% ==========================================================

recoveredBits = gf64ToBits(infoSymbols);

fprintf('\nSTEP 3: GF(64)-to-bits conversion completed.\n');
fprintf('Recovered number of bits = %d\n', length(recoveredBits));

if length(recoveredBits) == 288
    fprintf('Status: PASS - Correct 288 bits recovered.\n');
else
    fprintf('Status: FAIL - Incorrect number of recovered bits.\n');
end

if isequal(navBits, recoveredBits)
    fprintf('Verification: PASS - Original and recovered bits are identical.\n');
else
    fprintf('Verification: FAIL - Bit mismatch detected.\n');
end

%% =========================================================
% STEP 4: Load Official BeiDou H Matrix
% ==========================================================

codeDir = fileparts(mfilename('fullpath'));
projectRoot = fileparts(codeDir);

Hfile = fullfile(projectRoot, '04_Data', 'H_matrix.mat');
load(Hfile, 'H');

fprintf('\nSTEP 4: H matrix loaded successfully.\n');
fprintf('H matrix size = %d x %d\n', size(H,1), size(H,2));

if size(H,1) == 48 && size(H,2) == 96
    fprintf('Status: PASS - Correct H(48,96) matrix loaded.\n');
else
    fprintf('Status: FAIL - Incorrect H matrix.\n');
end

%% =========================================================
% STEP 5: 64-ary LDPC Encoding
% ==========================================================

codeword = ldpc64Encoder(infoSymbols, H);

fprintf('\nSTEP 5: 64-ary LDPC encoding completed.\n');
fprintf('Information symbols = %d\n', length(infoSymbols.x));
fprintf('Encoded symbols     = %d\n', length(codeword.x));

if length(codeword.x) == 96
    fprintf('Status: PASS - Correct 96-symbol codeword generated.\n');
else
    fprintf('Status: FAIL - Incorrect codeword length.\n');
end

%% =========================================================
% STEP 6: LDPC Syndrome Verification
% ==========================================================

syndrome = H * codeword;

fprintf('\nSTEP 6: LDPC syndrome verification.\n');

if all(syndrome.x == 0)
    fprintf('Syndrome Check: PASS - Valid LDPC codeword.\n');
else
    fprintf('Syndrome Check: FAIL - Invalid LDPC codeword.\n');
end

%% =========================================================
% STEP 7: Validate Encoder Using Official Reference Data
% ==========================================================

referenceMessageFile = ...
    fullfile(projectRoot, '04_Data', 'reference_message.mat');

referenceEncodedFile = ...
    fullfile(projectRoot, '04_Data', 'reference_encoded.mat');

if isfile(referenceMessageFile) && isfile(referenceEncodedFile)

    load(referenceMessageFile, ...
        'reference_message', ...
        'reference_info_symbols');

    load(referenceEncodedFile, ...
        'reference_encoded_bits', ...
        'reference_encoded_symbols');

    referenceCodeword = ...
        ldpc64Encoder(reference_info_symbols, H);

    fprintf('\nSTEP 7: BeiDou reference encoder validation.\n');

    if isequal( ...
            referenceCodeword.x(:), ...
            reference_encoded_symbols.x(:))

        fprintf(['Status: PASS - Encoder matches ', ...
                 'BeiDou reference codeword.\n']);
    else
        fprintf(['Status: FAIL - Encoder does not match ', ...
                 'BeiDou reference codeword.\n']);
    end

else
    fprintf('\nSTEP 7: Reference files not found.\n');
    fprintf('Run createReferenceData once before final validation.\n');
end

%% =========================================================
% STEP 8: Convert 96 GF(64) Symbols to 576 Bits
% ==========================================================

encodedBits = gf64ToBits(codeword);

fprintf('\nSTEP 8: Encoded bit conversion completed.\n');
fprintf('Encoded bit length = %d\n', length(encodedBits));

if length(encodedBits) == 576
    fprintf('Status: PASS - Correct 576 encoded bits generated.\n');
else
    fprintf('Status: FAIL - Incorrect encoded bit length.\n');
end

%% =========================================================
% STEP 9: Add BeiDou Preamble + BPSK Modulation
% ==========================================================

% Official 24-bit B-CNAV2 preamble
% Hexadecimal: E24DE8

preamble = ('111000100100110111101000' - '0')';

txBits = [
    preamble;
    encodedBits
];

% BeiDou logic mapping:
% Bit 0 -> +1
% Bit 1 -> -1

txFrame = 1 - 2 * txBits;

fprintf('\nSTEP 9: BPSK modulation completed.\n');
fprintf('Preamble length           = %d\n', length(preamble));
fprintf('Encoded payload length    = %d\n', length(encodedBits));
fprintf('Total transmitted symbols = %d\n', length(txFrame));

if length(txFrame) == 600
    fprintf('Status: PASS - Correct 600-symbol transmitted frame generated.\n');
else
    fprintf('Status: FAIL - Incorrect transmitted frame length.\n');
end

%% =========================================================
% STEP 10: AWGN Channel
% ==========================================================

SNRdB = 4;

[rxFrame, noiseVariance] = ...
    addAWGN(txFrame, SNRdB);

% Perfect synchronization is assumed.
% Remove the first 24 received preamble samples.

rxPayload = rxFrame(25:end);

fprintf('\nSTEP 10: AWGN channel completed.\n');
fprintf('SNR = %.1f dB\n', SNRdB);
fprintf('Received payload length = %d\n', length(rxPayload));

if length(rxPayload) == 576
    fprintf('Status: PASS - Correct 576 received payload samples.\n');
else
    fprintf('Status: FAIL - Incorrect received payload length.\n');
end

%% =========================================================
% STEP 11: 64-ary LDPC Decoding
% ==========================================================

maxIterations = 15;

% Number of reliability candidates retained
truncatedSymbols = 16;

[decodedSymbols, decoderSuccess, iterations] = ...
    ldpc64Decoder( ...
        rxPayload, ...
        noiseVariance, ...
        H, ...
        maxIterations, ...
        truncatedSymbols);

decodedBits = gf64ToBits(decodedSymbols);

fprintf('\nSTEP 11: 64-ary LDPC decoding completed.\n');
fprintf('Recovered information bits = %d\n', length(decodedBits));
fprintf('Decoder iterations = %d\n', iterations);

if length(decodedBits) == 288
    fprintf('Status: PASS - Correct 288 information bits recovered.\n');
else
    fprintf('Status: FAIL - Incorrect recovered message length.\n');
end

if decoderSuccess
    fprintf('Decoder Status: PASS - Valid LDPC codeword recovered.\n');
else
    fprintf('Decoder Status: WARNING - Maximum iterations reached.\n');
end

%% =========================================================
% STEP 12: BER Calculation for Demo Frame
% ==========================================================

[BER, numErrors] = ...
    calculateBER(navBits, decodedBits);

fprintf('\nSTEP 12: BER calculation completed.\n');
fprintf('Bit errors = %d\n', numErrors);
fprintf('BER = %.8f\n', BER);

if BER == 0
    fprintf('Demo Result: Original and decoded messages are identical.\n');
else
    fprintf('Demo Result: Some bit errors remain after decoding.\n');
end

%% =========================================================
% STEP 13: BER versus SNR Simulation
% ==========================================================

snrValues = 0:2:10;

% Start small for MATLAB Online testing.
% Increase numFrames for a more reliable BER estimate.

numFrames = 2;

berValues = zeros(size(snrValues));

fprintf('\n============================================\n');
fprintf(' STEP 13: BER vs SNR SIMULATION\n');
fprintf('============================================\n');

for s = 1:length(snrValues)

    currentSNR = snrValues(s);

    totalErrors = 0;
    totalBits = 0;

    fprintf('\nRunning SNR = %d dB\n', currentSNR);

    for frame = 1:numFrames

        %% Generate navigation message
        frameBits = createNavigationMessage();

        %% Convert to GF(64)
        frameSymbols = bitsToGF64(frameBits);

        %% LDPC encoding
        frameCodeword = ...
            ldpc64Encoder(frameSymbols, H);

        %% Convert encoded symbols to bits
        frameEncodedBits = ...
            gf64ToBits(frameCodeword);

        %% Add preamble
        frameTxBits = [
            preamble;
            frameEncodedBits
        ];

        %% BPSK modulation
        frameTx = 1 - 2 * frameTxBits;

        %% AWGN channel
        [frameRx, frameNoiseVariance] = ...
            addAWGN(frameTx, currentSNR);

        %% Remove preamble
        frameRxPayload = frameRx(25:end);

        %% LDPC decoder
        [frameDecodedSymbols, ~, ~] = ...
            ldpc64Decoder( ...
                frameRxPayload, ...
                frameNoiseVariance, ...
                H, ...
                maxIterations, ...
                truncatedSymbols);

        %% Convert decoded symbols to bits
        frameRecoveredBits = ...
            gf64ToBits(frameDecodedSymbols);

        %% Count errors
        [~, frameErrors] = ...
            calculateBER( ...
                frameBits, ...
                frameRecoveredBits);

        totalErrors = totalErrors + frameErrors;
        totalBits = totalBits + length(frameBits);

    end

    %% BER for this SNR
    berValues(s) = totalErrors / totalBits;

    fprintf('SNR = %2d dB   BER = %.8f\n', ...
        currentSNR, berValues(s));

end

fprintf('\nBER simulation completed successfully.\n');

%% =========================================================
% STEP 14: Save BER Results
% ==========================================================

resultsDir = ...
    fullfile(projectRoot, '05_Results');

if ~exist(resultsDir, 'dir')
    mkdir(resultsDir);
end

save( ...
    fullfile(resultsDir, 'BER_Result.mat'), ...
    'snrValues', ...
    'berValues', ...
    'numFrames');

fprintf('\nSTEP 14: BER_Result.mat saved successfully.\n');

%% =========================================================
% STEP 15: Generate Result Graphs and Excel Table
% ==========================================================

txPayload = txFrame(25:end);

plotResults( ...
    snrValues, ...
    berValues, ...
    navBits, ...
    txPayload, ...
    rxPayload, ...
    decodedBits, ...
    resultsDir);

fprintf('\nSTEP 15: Result graphs generated successfully.\n');

fprintf('Results saved inside:\n');
fprintf('%s\n', resultsDir);

%% =========================================================
% STEP 16: Input and Output Comparison
% ==========================================================

plotInputOutput( ...
    navBits, ...
    decodedBits, ...
    resultsDir);

fprintf('\nSTEP 16: Input and output graph generated.\n');

%% =========================================================
% STEP 17: Spectrogram Comparison
% ==========================================================

plotSpectrogram( ...
    txPayload, ...
    rxPayload, ...
    resultsDir);

fprintf('\nSTEP 17: Spectrogram generated successfully.\n');

%% =========================================================
% FINAL PROJECT STATUS
% ==========================================================

fprintf('\n============================================\n');
fprintf(' PROJECT SIMULATION COMPLETED SUCCESSFULLY\n');
fprintf('============================================\n');

fprintf('\nFinal Project Flow:\n');

fprintf('288-bit Navigation Message\n');
fprintf('       -> 48 GF(64) Symbols\n');
fprintf('       -> 96 LDPC Symbols\n');
fprintf('       -> 576 Encoded Bits\n');
fprintf('       -> BPSK + 24-bit Preamble\n');
fprintf('       -> 600-symbol Frame\n');
fprintf('       -> AWGN Channel\n');
fprintf('       -> 64-ary LDPC Decoder\n');
fprintf('       -> 288 Recovered Bits\n');
fprintf('       -> BER vs SNR\n');
fprintf('       -> Input/Output Comparison\n');
fprintf('       -> Spectrogram Comparison\n\n');

fprintf('All requested simulation stages completed.\n');
