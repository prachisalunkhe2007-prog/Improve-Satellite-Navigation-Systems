function bits = gf64ToBits(gfSymbols)

m = 6;

% Extract decimal values from GF object
values = gfSymbols.x(:);

% Convert each decimal value to 6 binary bits
binaryMatrix = zeros(length(values),m);

for i = 1:length(values)
    binaryMatrix(i,:) = bitget(values(i),m:-1:1);
end

% Convert matrix back into one column of bits
bits = reshape(binaryMatrix.',[],1);

end